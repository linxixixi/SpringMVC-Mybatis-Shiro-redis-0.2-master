package com.sojson.core.statics;
/**
 * 不可变参数定义
 * 第三方参数
 * @author zhou-baicheng
 *
 */
public interface APPKEY {
	/**豆瓣*/
	String  DOUBAN_API_KEY = "";
	String  DOUBAN_SECRET_KEY = "";
	/**豆瓣*/
	
	/**新浪*/
	String  SINA_API_KEY = "";
	String  SINA_SECRET_KEY = "";
	String 	SINA_TOKEN = "";
	/**新浪*/
	/**QQ*/
	String  QQ_OPEN_ID = "";
	String  QQ_SECRET_KEY = "";
	String 	QQ_TOKEN = "";
	/**QQ*/
	
	
	
}
